#include <string>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int main() {
    vector<float> v1, v2, v3;
    new vector<string>;

    for (int i = 0; i <= 25; i++) {
        v1.push_back(i);
        v2.push_back(i + 1);
        v3.push_back(v1[i] + v2[i]);

        cout << "\nv1[" << i << "]: " << v1[i] << endl;
        cout << "v2[" << i << "]: " << v2[i] << endl;
        cout << "v3[" << i << "]: " <<  v3[i] << endl;
    }
}