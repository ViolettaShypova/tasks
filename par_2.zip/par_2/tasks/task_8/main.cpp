#include <string>
#include <iostream>
#include <fstream>
#include <vector>

 using namespace std;

int main() {
    vector<float> v;
    new vector<string>;

    for( int i = 0; i <= 25; i++) {
        v.push_back(i);

        cout << v[i] << endl;
    }

}