#include <iostream>
using namespace std;

int main() {
cout << "Surname Name: "<< "Violetta Shypova\n" <<  "My age: "<< "19\n" << "City: " << "Kharkov" << endl;
}
