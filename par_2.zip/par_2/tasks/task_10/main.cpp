#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
using namespace std;

int main() {
    vector<float> v1;
    new vector<string>;
    for (int i = 0; i <= 25; i++) {
        v1.push_back(i);
        cout << "(before)[" << i << "]: " << v1[i] << endl;
        v1[i] = pow(v1[i], 2);
        cout << "(after)[" << i << "]: " << v1[i] << endl << endl;
    }
}