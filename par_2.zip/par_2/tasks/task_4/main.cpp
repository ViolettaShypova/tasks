#include <cstring>
#include <iostream>
#include <fstream>
#include <cctype>
using namespace std;

int main() {
    const int len = 100;
    char word[len], line[len];
    cout << "Enter word for the search: ";
    cin >> word;
    int l_word = strlen(word);
    ifstream fin("test.txt");

    int count = 0;
    while (fin.getline(line, len)) {
        cout << line << endl;

        char *p = line;
        while (p = strstr(p, word)) {
            cout << "coincidence: " << p << endl;
            char *c = p;
            p += l_word;


            if (ispunct(*p) || isspace(*p) || (*p == '\0'))
                count++;
        }
        cout << "number of occurrences in a string: " << count << endl;

    }

}