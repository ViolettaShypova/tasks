#include <iostream>
using namespace std;

int main() {
    int r;

    cout << "Enter radius circle: ";
    cin >> r;

    cout << "Area of the circle = " << 3.14 * r * r << endl;
}
