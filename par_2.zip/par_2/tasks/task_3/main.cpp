#include <string>
#include <iostream>
#include <fstream>
using namespace std;

int main() {
    int word, count = 0;
    ifstream in("test.txt");
    string s, line;
    while(getline(in, line))
        s += line + "\n";
    cout << s;
    int i = 0;
    while (s[i] == ' ' && s[i] != '\0')
        i++;
    word = 0;
    while (s[i] != '\0') {
        if (s[i] != ' ' && word == 0)
        {
            word = 1;
            count++;
        }
        else if (s[i] == ' ')
            word = 0;
        i++;
    }
    cout << "Количество слов в строке " << count;
    cin.get(); cin.get();
    return 0;
}
